package com.sovietindustry.tileentities;

public final class Lep750 {
    private Lep750() {
    }

    public static final double MAX_SPAN_750 = 250.0D;

    // Подвійні гірлянди вздовж лінії + розщеплена фаза з 4 проводів квадратом
    public static final int STRINGS = 2;
    public static final double STRING_SPACING = 0.70D;
    public static final int WIRES_PER_STRING = 4;
    public static final double BUNDLE_HALF = 0.22D;
    public static final double WIRE_SPACING = BUNDLE_HALF * 2.0D;

    // ---------------------------------------------------------------- проміжна опора (Фото 2)
    // Λ-подібні ноги, широко розставлені в основі й зведені до траверси; траверса — два ПЕРЕВЕРНУТІ трикутники
    // (вершини донизу, у верхівках ніг), що сходяться під кутом у центрі; над ними масивні V-подібні роги тросів.
    /** Висота колізії (до верху траверси). */
    public static final int HEIGHT = 25;

    public static final double LEG_BASE_X = 13.0D;
    public static final double LEG_TOP_X = 7.2D;
    /** Вершина ноги = нижня вершина перевернутого трикутника траверси. */
    public static final double LEG_TOP_Y = 21.2D;

    public static final double ARM_HALF = 14.4D;
    /** Нижній пояс траверси на краях і в центрі (звідси висять гірлянди). */
    public static final double ARM_Y = 23.0D;
    /** Верхній пояс траверси (плоский). */
    public static final double ARM_TOP_Y = 24.0D;

    public static final double HORN_TOP_Y = 29.5D;
    public static final double HORN_SPREAD = 2.6D;
    public static final double GROUND_X = LEG_TOP_X + HORN_SPREAD;
    public static final double GROUND_Y = HORN_TOP_Y + 0.32D;

    public static final double[] PHASE_X = { -14.0D, 0.0D, 14.0D };

    public static final int DISCS = 20;
    public static final double STRING_TOP = ARM_Y - 0.10D;
    public static final double YOKE_Y = ARM_Y - 3.95D;
    public static final double MOUNT_Y = ARM_Y - 4.35D;

    public static double discY(int k) {
        return STRING_TOP - 0.28D - k * 0.175D;
    }

    public static double legCentreX(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, y / LEG_TOP_Y));
        return LEG_BASE_X + (LEG_TOP_X - LEG_BASE_X) * f;
    }

    public static double legHalf(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, y / LEG_TOP_Y));
        return 1.2D + (0.55D - 1.2D) * f;
    }

    /** Профіль перевернутих трикутників: 0 на краях і в центрі, 1 над вершинами ніг. */
    public static double armTri(double ax) {
        ax = Math.abs(ax);
        if (ax <= LEG_TOP_X) return ax / LEG_TOP_X;
        return Math.max(0.0D, 1.0D - (ax - LEG_TOP_X) / (ARM_HALF - LEG_TOP_X));
    }

    /** Висота нижнього пояса траверси в точці x. */
    public static double armBottomY(double x) {
        return ARM_Y - (ARM_Y - LEG_TOP_Y) * armTri(x);
    }

    public static double[][] pMounts() {
        return new double[][] {
            { PHASE_X[0], MOUNT_Y, 0.0D },
            { PHASE_X[1], MOUNT_Y, 0.0D },
            { PHASE_X[2], MOUNT_Y, 0.0D }
        };
    }

    // ---------------------------------------------------------------- анкерно-кутова опора (Фото 1)
    // Три окремі високі ґратчасті вежі: дуже широка основа, різке звуження до талії й стрімка верхня секція.
    public static final int A_HEIGHT = 27;
    public static final double A_NECK_Y = 17.0D;
    public static final double A_TOP = 26.0D;
    public static final double A_BASE_HALF = 6.2D;
    public static final double A_TOWER_X = 20.0D;

    public static final double A_MOUNT_Y = 20.0D;
    public static final double A_STRING_LEN = 3.6D;
    public static final double A_GROUND_Y = A_TOP + 0.55D;
    public static final double A_CORONA_RING_R = 0.48D;
    public static final double A_STANDOFF = 1.6D;

    /** Права вежа: консоль-прапор у вигляді прямокутного трикутника (горизонтальний верх, гіпотенуза донизу до щогли). */
    public static final double A_ARM_Y = A_TOP - 1.2D;
    public static final double A_ARM_DEPTH = 2.4D;
    public static final double A_ARM_LEN = 7.0D;
    public static final double A_ARM_RISE = 0.0D;
    public static final double A_JUMP_Z = 0.35D;
    public static final double A_JUMP_LEN = 4.2D;
    public static final int A_JUMPER_MOUNT = 2;

    /** Бічна підтримка шлейфу фаз 0 і 1: горизонтальна гірлянда від сусідньої вежі. */
    public static final double A_SUP_REACH = 4.0D;
    public static final double A_SUP_STUB = 0.8D;

    /** Точка кріплення горизонтальної гірлянди на сусідній вежі (X, Y, Z локально). */
    public static double[] aSupportAttach(int mount) {
        return new double[] { mount * A_TOWER_X - (angleHalf(A_MOUNT_Y) + A_SUP_STUB), A_MOUNT_Y, 0.0D };
    }

    /** Кінець гірлянди (там, де дріт фази проходить на гірлянду-вихід). */
    public static double[] aSupportEnd(int mount) {
        return new double[] { (mount - 1) * A_TOWER_X + A_SUP_REACH, A_MOUNT_Y, 0.0D };
    }

    public static double angleHalf(double y) {
        if (y <= A_NECK_Y) {
            double f = Math.max(0.0D, y / A_NECK_Y);
            return A_BASE_HALF + (1.4D - A_BASE_HALF) * f;
        }
        double f = Math.min(1.0D, (y - A_NECK_Y) / (A_TOP - A_NECK_Y));
        return 1.2D + (0.5D - 1.2D) * f;
    }

    public static double[][] aMounts() {
        return new double[][] {
            { -A_TOWER_X, A_MOUNT_Y, 0.0D },
            {  0.0D,      A_MOUNT_Y, 0.0D },
            {  A_TOWER_X, A_MOUNT_Y, 0.0D }
        };
    }

    /** Верхні підвісні гірлянди правої вежі: {верх, низ}, локальні координати. */
    public static double[][][] aJumperStrings() {
        double x = A_TOWER_X + A_ARM_LEN;
        double top = A_ARM_Y + A_ARM_RISE - 0.1D;
        double bot = top - A_JUMP_LEN;
        return new double[][][] {
            { { x, top,  A_JUMP_Z }, { x, bot,  A_JUMP_Z } },
            { { x, top, -A_JUMP_Z }, { x, bot, -A_JUMP_Z } }
        };
    }
}

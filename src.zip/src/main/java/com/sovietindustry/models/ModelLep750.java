package com.sovietindustry.models;

import org.lwjgl.opengl.GL11;

import com.sovietindustry.SovietIndustryMod;
import com.sovietindustry.render.LepGeo;
import com.sovietindustry.tileentities.Lep750;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.ResourceLocation;

@SideOnly(Side.CLIENT)
public class ModelLep750 {

    private static final ResourceLocation ATLAS =
        new ResourceLocation(SovietIndustryMod.MODID, "textures/models/lep110_single.png");
    private static final ResourceLocation LATTICE_STEEL =
        new ResourceLocation(SovietIndustryMod.MODID, "textures/models/lep_steel.png");
    private static final double TEX = 128.0D;

    private static final double[] STEEL = { 64.0D, 4.0D, 80.0D, 12.0D };
    private static final double[] STEEL_DARK = { 0.0D, 84.0D, 16.0D, 92.0D };
    private static final double[] GLASS = { 64.0D, 50.0D, 80.0D, 54.0D };
    private static final double[] CAP = { 96.0D, 48.0D, 112.0D, 56.0D };

    private static final int[][] SIGN = { { -1, -1 }, { 1, -1 }, { 1, 1 }, { -1, 1 } };

    private final boolean angle;
    private int listSteel = -1;
    private int listAtlas = -1;

    public ModelLep750(boolean angle) {
        this.angle = angle;
    }

    public void renderAll() {
        if (listSteel < 0) {
            listSteel = GLAllocation.generateDisplayLists(1);
            GL11.glNewList(listSteel, GL11.GL_COMPILE);
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            if (angle) {
                buildAngleSteel(t);
            } else {
                buildPortalSteel(t);
            }
            t.draw();
            GL11.glEndList();
        }
        Minecraft.getMinecraft().renderEngine.bindTexture(LATTICE_STEEL);
        GL11.glCallList(listSteel);

        if (angle) return;
        if (listAtlas < 0) {
            listAtlas = GLAllocation.generateDisplayLists(1);
            GL11.glNewList(listAtlas, GL11.GL_COMPILE);
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            buildPortalAtlas(t);
            t.draw();
            GL11.glEndList();
        }
        Minecraft.getMinecraft().renderEngine.bindTexture(ATLAS);
        GL11.glCallList(listAtlas);
    }

    // ------------------------------------------------------------ допоміжні

    private static void lb(Tessellator t, double[] a, double[] b, double th) {
        LepGeo.beam(t, a[0], a[1], a[2], b[0], b[1], b[2], th);
    }

    private static void lb(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beam(t, x1, y1, z1, x2, y2, z2, th);
    }

    private static void sb(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beamUV(t, x1, y1, z1, x2, y2, z2, th, STEEL, TEX);
    }

    private static void sd(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beamUV(t, x1, y1, z1, x2, y2, z2, th, STEEL_DARK, TEX);
    }

    private static void lattice(Tessellator t, double[] ys, double[] cx, double[] hw, double[] hd,
                                double legT, double barT, double diagT, int crossEvery) {
        int n = ys.length;
        double[][][] c = new double[n][4][];
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 4; k++) {
                c[i][k] = new double[] { cx[i] + SIGN[k][0] * hw[i], ys[i], SIGN[k][1] * hd[i] };
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int k = 0; k < 4; k++) {
                lb(t, c[i][k], c[i + 1][k], legT);
            }
        }
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 4; k++) {
                lb(t, c[i][k], c[i][(k + 1) & 3], barT);
            }
            if (crossEvery > 0 && i > 0 && i < n - 1 && i % crossEvery == 0) {
                lb(t, c[i][0], c[i][2], diagT);
                lb(t, c[i][1], c[i][3], diagT);
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int k = 0; k < 4; k++) {
                int k1 = (k + 1) & 3;
                lb(t, c[i][k], c[i + 1][k1], diagT);
                lb(t, c[i][k1], c[i + 1][k], diagT);
            }
        }
    }

    // ------------------------------------------------------------ проміжна опора (Фото 2)

    private void buildPortalSteel(Tessellator t) {
        for (int side = -1; side <= 1; side += 2) {
            leg(t, side);
            neck(t, side);
            horns(t, side);
            foot(t, side);
        }
        crossarm(t);
    }

    /** Λ-подібна нога: широка в основі, зведена до вершини траверси. */
    private void leg(Tessellator t, int side) {
        int n = 14;
        double[] ys = new double[n + 1];
        double[] cx = new double[n + 1];
        double[] hw = new double[n + 1];
        for (int i = 0; i <= n; i++) {
            ys[i] = Lep750.LEG_TOP_Y * i / n;
            cx[i] = side * Lep750.legCentreX(ys[i]);
            hw[i] = Lep750.legHalf(ys[i]);
        }
        lattice(t, ys, cx, hw, hw, 0.15D, 0.07D, 0.055D, 2);
        // вузол-«п'ята» у вершині ноги, куди сходяться пояси траверси
        LepGeo.box(t, side * Lep750.LEG_TOP_X, Lep750.LEG_TOP_Y, 0.0D, 0.55D, 0.10D, 0.55D);
    }

    /** Вертикальна шийка між вершиною ноги й верхнім поясом траверси. */
    private void neck(Tessellator t, int side) {
        double[] ys = { Lep750.LEG_TOP_Y, (Lep750.LEG_TOP_Y + Lep750.ARM_TOP_Y) * 0.5D, Lep750.ARM_TOP_Y };
        double[] cx = { side * Lep750.LEG_TOP_X, side * Lep750.LEG_TOP_X, side * Lep750.LEG_TOP_X };
        double[] hw = { 0.45D, 0.45D, 0.45D };
        lattice(t, ys, cx, hw, hw, 0.15D, 0.08D, 0.06D, 0);
    }

    /** Одинарний ґратчастий ріг, нахилений назовні (як на кресленні ПП750): з верхнього пояса вгору до затискача троса. */
    private void horns(Tessellator t, int side) {
        double y0 = Lep750.ARM_TOP_Y;
        double y1 = Lep750.HORN_TOP_Y;
        int n = 7;
        double[] ys = new double[n];
        double[] cx = new double[n];
        double[] hw = new double[n];
        for (int i = 0; i < n; i++) {
            double f = (double) i / (n - 1);
            ys[i] = y0 + (y1 - y0) * f;
            cx[i] = side * (Lep750.LEG_TOP_X + Lep750.HORN_SPREAD * f);
            hw[i] = 0.40D + (0.17D - 0.40D) * f;
        }
        lattice(t, ys, cx, hw, hw, 0.15D, 0.07D, 0.05D, 2);
        LepGeo.box(t, side * Lep750.LEG_TOP_X, y0 + 0.2D, 0.0D, 0.65D, 0.22D, 0.55D);
        double ox = cx[n - 1];
        LepGeo.box(t, ox, y1 + 0.10D, 0.0D, 0.26D, 0.10D, 0.26D);
        lb(t, ox, y1 + 0.1D, -0.45D, ox, y1 + 0.1D, 0.45D, 0.10D);
    }

    private void foot(Tessellator t, int side) {
        double x = side * Lep750.LEG_BASE_X;
        LepGeo.box(t, x, 0.20D, 0.0D, 1.35D, 0.20D, 1.35D);
        LepGeo.box(t, x, 0.52D, 0.0D, 1.05D, 0.12D, 1.05D);
        for (int k = 0; k < 4; k++) {
            double hb = Lep750.legHalf(0.0D);
            LepGeo.box(t, x + SIGN[k][0] * hb, 0.85D, SIGN[k][1] * hb, 0.26D, 0.18D, 0.26D);
        }
    }

    /**
     * Траверса з двох ПЕРЕВЕРНУТИХ трикутників: верхній пояс плоский, нижній пояс опускається до вершин ніг
     * і піднімається до краю й до центру, де обидва трикутники сходяться під кутом.
     */
    private void crossarm(Tessellator t) {
        double half = Lep750.ARM_HALF;
        double topY = Lep750.ARM_TOP_Y;
        int panels = 16;
        double[] xs = new double[panels + 1];
        double[] yb = new double[panels + 1];
        double[] zh = new double[panels + 1];
        for (int p = 0; p <= panels; p++) {
            xs[p] = -half + 2.0D * half * p / panels;
            yb[p] = Lep750.armBottomY(xs[p]);
            zh[p] = 0.50D + 0.45D * Lep750.armTri(xs[p]);
        }

        for (int z = -1; z <= 1; z += 2) {
            for (int p = 0; p < panels; p++) {
                lb(t, xs[p], topY, z * zh[p], xs[p + 1], topY, z * zh[p + 1], 0.13D);
                lb(t, xs[p], yb[p], z * zh[p], xs[p + 1], yb[p + 1], z * zh[p + 1], 0.13D);
                // розкоси: у кожному трикутнику йдуть до вершини ноги
                if (p % 2 == 0) {
                    lb(t, xs[p], topY, z * zh[p], xs[p + 1], yb[p + 1], z * zh[p + 1], 0.065D);
                } else {
                    lb(t, xs[p], yb[p], z * zh[p], xs[p + 1], topY, z * zh[p + 1], 0.065D);
                }
            }
            for (int p = 0; p <= panels; p++) {
                lb(t, xs[p], yb[p], z * zh[p], xs[p], topY, z * zh[p], 0.075D);
            }
        }
        for (int p = 0; p <= panels; p++) {
            lb(t, xs[p], yb[p], -zh[p], xs[p], yb[p], zh[p], 0.08D);
            lb(t, xs[p], topY, -zh[p], xs[p], topY, zh[p], 0.07D);
            if (p % 2 == 0 && p < panels) {
                lb(t, xs[p], topY, -zh[p], xs[p + 1], topY, zh[p + 1], 0.045D);
                lb(t, xs[p], topY, zh[p], xs[p + 1], topY, -zh[p + 1], 0.045D);
            }
        }

        // поздовжні кронштейни під дві гірлянди на кожній фазі
        double halfZ = Lep750.STRING_SPACING * 0.5D;
        for (double px : Lep750.PHASE_X) {
            double by = Lep750.armBottomY(px);
            lb(t, px, by - 0.04D, -halfZ, px, by - 0.04D, halfZ, 0.10D);
            for (int sz = -1; sz <= 1; sz += 2) {
                LepGeo.box(t, px, by - 0.08D, sz * halfZ, 0.10D, 0.07D, 0.10D);
            }
        }
    }

    // ------------------------------------------------------------ проміжна опора: гірлянди, місток

    private void buildPortalAtlas(Tessellator t) {
        for (double px : Lep750.PHASE_X) {
            phaseString(t, px);
        }
        for (int side = -1; side <= 1; side += 2) {
            groundHook(t, side);
            // відтяжка від вершини ноги до центрального якоря (як на кресленні)
            sd(t, side * Lep750.LEG_TOP_X, Lep750.LEG_TOP_Y - 0.4D, 0.0D, 0.0D, 0.5D, 0.0D, 0.06D);
            LepGeo.boxUV(t, side * Lep750.LEG_TOP_X, Lep750.LEG_TOP_Y - 0.4D, 0.0D, 0.10D, 0.10D, 0.10D, CAP, TEX);
        }
        LepGeo.boxUV(t, 0.0D, 0.25D, 0.0D, 0.35D, 0.25D, 0.35D, STEEL, TEX);
    }

    private void phaseString(Tessellator t, double px) {
        double top = Lep750.STRING_TOP;
        double lastDisc = Lep750.discY(Lep750.DISCS - 1);
        double rodTop = top - 0.12D;
        double rodBottom = lastDisc - 0.16D;
        double halfZ = Lep750.STRING_SPACING * 0.5D;
        double by = Lep750.armBottomY(px);

        for (int sz = -1; sz <= 1; sz += 2) {
            double zPos = sz * halfZ;
            sb(t, px, by - 0.04D, zPos, px, top - 0.04D, zPos, 0.08D);
            LepGeo.boxUV(t, px, top - 0.07D, zPos, 0.09D, 0.06D, 0.09D, STEEL, TEX);
            LepGeo.beamUV(t, px, rodTop, zPos, px, Lep750.YOKE_Y, zPos, 0.055D, CAP, TEX);
            for (int k = 0; k < Lep750.DISCS; k++) {
                LepGeo.boxUV(t, px, Lep750.discY(k), zPos, 0.19D, 0.03D, 0.19D, GLASS, TEX);
            }
            LepGeo.beamUV(t, px, rodTop, zPos, px, rodTop - 0.12D, zPos, 0.11D, CAP, TEX);
            LepGeo.beamUV(t, px, rodBottom + 0.12D, zPos, px, rodBottom, zPos, 0.11D, CAP, TEX);
        }

        double cy = Lep750.MOUNT_Y;
        double h = Lep750.BUNDLE_HALF;
        LepGeo.boxUV(t, px, Lep750.YOKE_Y, 0.0D, 0.09D, 0.065D, halfZ + 0.16D, STEEL, TEX);
        sd(t, px, Lep750.YOKE_Y - 0.08D, -halfZ, px, Lep750.YOKE_Y - 0.08D, halfZ, 0.045D);
        sb(t, px, Lep750.YOKE_Y, 0.0D, px, cy + h, 0.0D, 0.06D);

        for (int k = 0; k < 4; k++) {
            int kn = (k + 1) & 3;
            double x0 = px + SIGN[k][0] * h, y0 = cy + SIGN[k][1] * h;
            double x1 = px + SIGN[kn][0] * h, y1 = cy + SIGN[kn][1] * h;
            sb(t, x0, y0, 0.0D, x1, y1, 0.0D, 0.04D);
        }
        sd(t, px - h, cy - h, 0.0D, px + h, cy + h, 0.0D, 0.025D);
        sd(t, px - h, cy + h, 0.0D, px + h, cy - h, 0.0D, 0.025D);
        for (int k = 0; k < 4; k++) {
            LepGeo.boxUV(t, px + SIGN[k][0] * h, cy + SIGN[k][1] * h, 0.0D, 0.075D, 0.075D, 0.11D, CAP, TEX);
        }
    }

    /** Затискач троса на кронштейні зовнішньої гілки рога. */
    private void groundHook(Tessellator t, int side) {
        double hookX = side * Lep750.GROUND_X;
        double gY = Lep750.GROUND_Y;
        sb(t, hookX, Lep750.HORN_TOP_Y + 0.1D, 0.0D, hookX, gY + 0.12D, 0.0D, 0.07D);
        LepGeo.boxUV(t, hookX, gY + 0.12D, 0.0D, 0.11D, 0.045D, 0.11D, CAP, TEX);
        LepGeo.boxUV(t, hookX, gY + 0.04D, 0.0D, 0.20D, 0.04D, 0.20D, GLASS, TEX);
        LepGeo.boxUV(t, hookX, gY - 0.03D, 0.0D, 0.07D, 0.04D, 0.07D, CAP, TEX);
    }

    // ------------------------------------------------------------ анкерно-кутова У750 (Фото 1): лише сталевий каркас

    private void buildAngleSteel(Tessellator t) {
        for (int idx = -1; idx <= 1; idx++) {
            tower(t, idx * Lep750.A_TOWER_X, idx != 0, idx == 1, idx >= 0);
        }
    }

    private void tower(Tessellator t, double tx, boolean groundWire, boolean jumperTower, boolean stub) {
        // 1. Нижня широка секція (0 .. талія)
        int nLow = 12;
        double[] ysLow = new double[nLow];
        double[] cxLow = new double[nLow];
        double[] hwLow = new double[nLow];
        for (int i = 0; i < nLow; i++) {
            ysLow[i] = Lep750.A_NECK_Y * i / (nLow - 1);
            cxLow[i] = tx;
            hwLow[i] = Lep750.angleHalf(ysLow[i]);
        }
        lattice(t, ysLow, cxLow, hwLow, hwLow, 0.28D, 0.11D, 0.09D, 2);

        // пояс-«коміра» на талії
        double nh = Lep750.angleHalf(Lep750.A_NECK_Y) + 0.18D;
        for (int k = 0; k < 4; k++) {
            lb(t, tx + SIGN[k][0] * nh, Lep750.A_NECK_Y, SIGN[k][1] * nh,
                  tx + SIGN[(k + 1) & 3][0] * nh, Lep750.A_NECK_Y, SIGN[(k + 1) & 3][1] * nh, 0.14D);
        }

        // 2. Стрімка верхня секція
        int nTop = 6;
        double[] ysTop = new double[nTop];
        double[] cxTop = new double[nTop];
        double[] hwTop = new double[nTop];
        for (int i = 0; i < nTop; i++) {
            ysTop[i] = Lep750.A_NECK_Y + (Lep750.A_TOP - Lep750.A_NECK_Y) * i / (nTop - 1);
            cxTop[i] = tx;
            hwTop[i] = Lep750.angleHalf(ysTop[i]);
        }
        lattice(t, ysTop, cxTop, hwTop, hwTop, 0.13D, 0.065D, 0.05D, 2);

        // 3. Фундаментні башмаки
        double hb = Lep750.angleHalf(0.0D);
        for (int k = 0; k < 4; k++) {
            LepGeo.box(t, tx + SIGN[k][0] * hb, 0.3D, SIGN[k][1] * hb, 0.6D, 0.3D, 0.6D);
        }

        // 4. Консолі під натяжні гірлянди (вперед і назад вздовж лінії), сталева ферма-кронштейн
        double my = Lep750.A_MOUNT_Y;
        for (int z = -1; z <= 1; z += 2) {
            double so = Lep750.A_STANDOFF;
            lb(t, tx, my, 0.0D, tx, my, z * so, 0.13D);
            lb(t, tx, my - 1.1D, 0.0D, tx, my, z * so, 0.09D);
            lb(t, tx - 0.5D, my, z * so, tx + 0.5D, my, z * so, 0.12D);
            LepGeo.box(t, tx, my, z * so, 0.26D, 0.10D, 0.14D);
        }

        // 5. Голівка вежі й шпиль громовідводу
        double top = Lep750.A_TOP;
        LepGeo.box(t, tx, top, 0.0D, 0.55D, 0.10D, 0.55D);
        lb(t, tx, top - 0.1D, 0.0D, tx, top + 1.0D, 0.0D, 0.09D);
        if (groundWire) {
            lb(t, tx - 0.5D, top + 0.2D, 0.0D, tx + 0.5D, top + 0.2D, 0.0D, 0.08D);
            LepGeo.box(t, tx, Lep750.A_GROUND_Y - 0.1D, 0.0D, 0.14D, 0.07D, 0.14D);
        }

        // 6. Упор під горизонтальну допоміжну гірлянду сусідньої фази (на боці, зверненому до сусідньої вежі)
        if (stub) {
            double sh = Lep750.angleHalf(my);
            lb(t, tx - sh, my, 0.0D, tx - sh - Lep750.A_SUP_STUB, my, 0.0D, 0.12D);
            lb(t, tx - sh, my - 0.8D, 0.0D, tx - sh - Lep750.A_SUP_STUB, my, 0.0D, 0.07D);
            LepGeo.box(t, tx - sh - Lep750.A_SUP_STUB, my, 0.0D, 0.10D, 0.14D, 0.14D);
        }

        // 7. Права вежа: консоль-прапор — прямокутний трикутник, ширина біля щогли = ширині щогли
        if (jumperTower) {
            double w0 = Lep750.angleHalf(Lep750.A_ARM_Y);
            flag(t, tx, Lep750.A_ARM_Y, Lep750.A_ARM_LEN, Lep750.A_ARM_DEPTH, w0, 0.26D);
            double ex = tx + Lep750.A_ARM_LEN;
            for (int z = -1; z <= 1; z += 2) {
                LepGeo.box(t, ex, Lep750.A_ARM_Y - 0.12D, z * Lep750.A_JUMP_Z, 0.09D, 0.07D, 0.09D);
            }
            lb(t, ex, Lep750.A_ARM_Y - 0.12D, -Lep750.A_JUMP_Z, ex, Lep750.A_ARM_Y - 0.12D, Lep750.A_JUMP_Z, 0.08D);
        }
    }

    /** Ґратчастий прямокутний трикутник: горизонтальний верх, вертикаль біля щогли, гіпотенуза від щогли вгору до вістря. */
    private void flag(Tessellator t, double tx, double yTop, double len, double depth, double w0, double w1) {
        int n = 8;
        double[] xs = new double[n + 1], yb = new double[n + 1], w = new double[n + 1];
        for (int i = 0; i <= n; i++) {
            double f = (double) i / n;
            xs[i] = tx + len * f;
            yb[i] = yTop - depth * (1.0D - f);
            w[i] = w0 + (w1 - w0) * f;
        }
        for (int z = -1; z <= 1; z += 2) {
            for (int i = 0; i < n; i++) {
                lb(t, xs[i], yTop, z * w[i], xs[i + 1], yTop, z * w[i + 1], 0.13D);
                lb(t, xs[i], yb[i], z * w[i], xs[i + 1], yb[i + 1], z * w[i + 1], 0.12D);
                if (i % 2 == 0) {
                    lb(t, xs[i], yb[i], z * w[i], xs[i + 1], yTop, z * w[i + 1], 0.05D);
                } else {
                    lb(t, xs[i], yTop, z * w[i], xs[i + 1], yb[i + 1], z * w[i + 1], 0.05D);
                }
            }
            for (int i = 0; i < n; i++) {
                lb(t, xs[i], yb[i], z * w[i], xs[i], yTop, z * w[i], 0.07D);
            }
        }
        for (int i = 0; i < n; i++) {
            lb(t, xs[i], yTop, -w[i], xs[i], yTop, w[i], 0.06D);
            lb(t, xs[i], yb[i], -w[i], xs[i], yb[i], w[i], 0.06D);
        }
    }
}

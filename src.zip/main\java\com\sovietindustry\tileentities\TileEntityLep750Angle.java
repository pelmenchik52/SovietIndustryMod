package com.sovietindustry.tileentities;

import com.sovietindustry.api.IStandoffPylon;

/**
 * Анкерно-кутова опора 750 кВ: три ґратчасті вежі як одна структура.
 * Без проводів — лише сталеві вежі без ізоляторів. Коли дріт підключено,
 * натяжні гірлянди по 20 тарілок з екрануючими коронними кругами та шлейфи
 * малює LepWireRenderer. Два грозотроси на вершинах крайніх веж.
 */
public class TileEntityLep750Angle extends TileEntityLep750Base implements IStandoffPylon {
    private static final double[][] GROUND = {
        { -Lep750.A_TOWER_X, Lep750.A_GROUND_Y, 0.0D },
        {  Lep750.A_TOWER_X, Lep750.A_GROUND_Y, 0.0D }
    };

    public TileEntityLep750Angle() {
    }

    @Override
    protected double[][] getLocalMounts() {
        return Lep750.aMounts();
    }

    @Override
    protected double[][] getLocalGround() {
        return GROUND;
    }

    @Override
    public boolean hasAnchorStrings() {
        return true;
    }

    @Override
    public double getStringLength() {
        return Lep750.A_STRING_LEN;
    }

    @Override
    public double getStringStandoff(int mount, double dirX, double dirZ) {
        // невеликий відступ 0.35 блока від осі вежі вздовж напрямку дроту
        return 0.35D;
    }
}

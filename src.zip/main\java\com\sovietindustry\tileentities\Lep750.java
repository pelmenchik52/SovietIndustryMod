package com.sovietindustry.tileentities;

public final class Lep750 {
    private Lep750() {
    }

    // ---------------------------------------------------------------- проміжна опора (Фото 1)
    /** Висота 25 блоків, ширина 24 блоки. */
    public static final int HEIGHT = 25;
    public static final double MAX_SPAN_750 = 250.0D;

    // Пучок із 4 проводів
    public static final int STRINGS = 1;
    public static final double STRING_SPACING = 0.0D;
    public static final int WIRES_PER_STRING = 4;
    public static final double BUNDLE_HALF = 0.25D; // півширина квадрата пучка (50x50 см)
    public static final double WIRE_SPACING = BUNDLE_HALF * 2.0D;

    /** Основи стійок на землі (відстань між п'ятами 16 блоків: від -8 до +8). */
    public static final double LEG_BASE_X = 8.0D;
    /** Висота траверси та верхівки стійок. */
    public static final double LEG_TOP_Y = 21.8D;
    /** Верхівки стійок сходяться до X = 5.5 (11 блоків між стійками біля траверси). */
    public static final double LEG_TOP_X = 5.5D;

    /** Траверса: ширина 24 блоки (ARM_HALF = 12.0D, від -12 до +12). */
    public static final double ARM_Y = 21.8D;
    public static final double ARM_HALF = 12.0D;

    /** Роги над стійками під грозотроси. */
    public static final double HORN_TOP_Y = 24.4D;
    public static final double HORN_TOP_X = 6.4D;
    /** Точка кріплення грозотроса під гачком рогу. */
    public static final double GROUND_X = 6.8D;
    public static final double GROUND_Y = 24.2D;

    /** Координати X трьох фаз: ліва (-10), центральна (0, всередині порталу), права (+10). */
    public static final double[] PHASE_X = { -10.0D, 0.0D, 10.0D };

    /** Підвісна гірлянда: 20 тарілок, ярмо й квадратна рамка 4 проводів. */
    public static final int DISCS = 20;
    public static final double STRING_TOP = ARM_Y - 0.08D; // 21.72D
    public static final double YOKE_Y = 19.20D;
    public static final double MOUNT_Y = 18.80D;

    public static double discY(int k) {
        return STRING_TOP - 0.35D - k * 0.10D;
    }

    /** Центр стійки на висоті y (нахилена всередину від LEG_BASE_X до LEG_TOP_X). */
    public static double legCentreX(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, y / LEG_TOP_Y));
        return LEG_BASE_X + (LEG_TOP_X - LEG_BASE_X) * f;
    }

    /** Півтовщина ґратчастої стійки на висоті y. */
    public static double legHalf(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, y / LEG_TOP_Y));
        if (f < 0.15D) return 0.32D + (0.46D - 0.32D) * (f / 0.15D);
        return 0.46D - (0.46D - 0.34D) * ((f - 0.15D) / 0.85D);
    }

    /** Центр рогу на висоті y (відхилений назовні від LEG_TOP_X до HORN_TOP_X). */
    public static double hornCentreX(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, (y - LEG_TOP_Y) / (HORN_TOP_Y - LEG_TOP_Y)));
        return LEG_TOP_X + (HORN_TOP_X - LEG_TOP_X) * f;
    }

    public static double hornHalf(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, (y - LEG_TOP_Y) / (HORN_TOP_Y - LEG_TOP_Y)));
        return 0.24D + (0.15D - 0.24D) * f;
    }

    // Відтяжки проміжної опори
    public static final double GUY_LEG_Y = 14.0D;
    public static final double GUY_ANCHOR_X = 10.5D;
    public static final double GUY_ANCHOR_Z = 7.0D;
    public static final double GUY_TIP_X = 14.5D;

    public static double[][] pMounts() {
        double[][] r = new double[3][];
        for (int i = 0; i < 3; i++) {
            r[i] = new double[] { PHASE_X[i], MOUNT_Y, 0.0D };
        }
        return r;
    }

    // ---------------------------------------------------------------- анкерно-кутова опора (Фото 2)
    /** Висота 19 блоків, ширина +-30 блоків (три вежі: X = -14, X = 0, X = +14). */
    public static final int A_HEIGHT = 19;
    public static final double A_TOP = 19.0D;
    public static final double A_TOWER_X = 14.0D;

    /** Висота кріплення натяжних гірлянд на голівці веж. */
    public static final double A_MOUNT_Y = 16.5D;
    /** Довжина натяжної гірлянди (20 тарілок + кінцева арматура). */
    public static final double A_STRING_LEN = 2.4D;
    /** Точка кріплення грозотроса на вістрі крайніх веж. */
    public static final double A_GROUND_Y = 19.0D;
    /** Радіус екрануючого круга натяжної гірлянди (захисне кільце від корони). */
    public static final double A_CORONA_RING_R = 0.44D;

    public static double angleHalf(double y) {
        double f = Math.max(0.0D, Math.min(1.0D, y / A_TOP));
        // пірамідальна вежа: основа 0.80 (1.6 блока), верхівка 0.22
        return 0.80D + (0.22D - 0.80D) * f;
    }

    public static double[][] aMounts() {
        return new double[][] {
            { -A_TOWER_X, A_MOUNT_Y, 0.0D },
            { 0.0D,       A_MOUNT_Y, 0.0D },
            {  A_TOWER_X, A_MOUNT_Y, 0.0D }
        };
    }
}

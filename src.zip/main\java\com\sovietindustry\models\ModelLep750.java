package com.sovietindustry.models;

import org.lwjgl.opengl.GL11;

import com.sovietindustry.SovietIndustryMod;
import com.sovietindustry.render.LepGeo;
import com.sovietindustry.tileentities.Lep750;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.ResourceLocation;

/**
 * Моделі опор 750 кВ.
 *
 * Проміжна (angle = false): висота 25 блоків, ширина 24 блоки. $\Lambda$-подібна опора на відтяжках.
 * Ґратчасті стійки на п'ятах нахилені всередину до траверси (ширина 24), над стійками роги з гачками під грозотроси.
 * Під траверсою три гірлянди по 20 тарілок із квадратною рамкою внизу (до кутів рамки чіпляються 4 проводи)
 * і 6 відтяжок до якорів у землі.
 *
 * Анкерно-кутова (angle = true): висота 19 блоків, ширина +-30 блоків. Сталевий каркас трьох окремих веж.
 * Гірлянди, кільця від корони й шлейфи малює LepWireRenderer, коли підключають дріт.
 */
@SideOnly(Side.CLIENT)
public class ModelLep750 {

    private static final ResourceLocation ATLAS =
        new ResourceLocation(SovietIndustryMod.MODID, "textures/models/lep110_single.png");
    private static final ResourceLocation LATTICE_STEEL =
        new ResourceLocation(SovietIndustryMod.MODID, "textures/models/lep_steel.png");
    private static final double TEX = 128.0D;

    private static final double[] STEEL = { 64.0D, 4.0D, 80.0D, 12.0D };
    private static final double[] STEEL_DARK = { 0.0D, 84.0D, 16.0D, 92.0D };
    private static final double[] GLASS = { 64.0D, 50.0D, 80.0D, 54.0D };
    private static final double[] CAP = { 96.0D, 48.0D, 112.0D, 56.0D };

    private static final int[][] SIGN = { { -1, -1 }, { 1, -1 }, { 1, 1 }, { -1, 1 } };

    private final boolean angle;
    private int listSteel = -1;
    private int listAtlas = -1;

    public ModelLep750(boolean angle) {
        this.angle = angle;
    }

    public void renderAll() {
        if (listSteel < 0) {
            listSteel = GLAllocation.generateDisplayLists(1);
            GL11.glNewList(listSteel, GL11.GL_COMPILE);
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            if (angle) {
                buildAngleSteel(t);
            } else {
                buildPortalSteel(t);
            }
            t.draw();
            GL11.glEndList();
        }
        Minecraft.getMinecraft().renderEngine.bindTexture(LATTICE_STEEL);
        GL11.glCallList(listSteel);

        if (angle) return;
        if (listAtlas < 0) {
            listAtlas = GLAllocation.generateDisplayLists(1);
            GL11.glNewList(listAtlas, GL11.GL_COMPILE);
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            buildPortalAtlas(t);
            t.draw();
            GL11.glEndList();
        }
        Minecraft.getMinecraft().renderEngine.bindTexture(ATLAS);
        GL11.glCallList(listAtlas);
    }

    // ------------------------------------------------------------ допоміжні

    private static void lb(Tessellator t, double[] a, double[] b, double th) {
        LepGeo.beam(t, a[0], a[1], a[2], b[0], b[1], b[2], th);
    }

    private static void lb(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beam(t, x1, y1, z1, x2, y2, z2, th);
    }

    private static void sb(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beamUV(t, x1, y1, z1, x2, y2, z2, th, STEEL, TEX);
    }

    private static void sd(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beamUV(t, x1, y1, z1, x2, y2, z2, th, STEEL_DARK, TEX);
    }

    private static void lattice(Tessellator t, double[] ys, double[] cx, double[] hw, double[] hd,
                                double legT, double barT, double diagT, int crossEvery) {
        int n = ys.length;
        double[][][] c = new double[n][4][];
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 4; k++) {
                c[i][k] = new double[] { cx[i] + SIGN[k][0] * hw[i], ys[i], SIGN[k][1] * hd[i] };
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int k = 0; k < 4; k++) {
                lb(t, c[i][k], c[i + 1][k], legT);
            }
        }
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 4; k++) {
                lb(t, c[i][k], c[i][(k + 1) & 3], barT);
            }
            if (crossEvery > 0 && i > 0 && i < n - 1 && i % crossEvery == 0) {
                lb(t, c[i][0], c[i][2], diagT);
                lb(t, c[i][1], c[i][3], diagT);
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int k = 0; k < 4; k++) {
                int k1 = (k + 1) & 3;
                lb(t, c[i][k], c[i + 1][k1], diagT);
                lb(t, c[i][k1], c[i + 1][k], diagT);
            }
        }
    }

    // ------------------------------------------------------------ проміжна опора: сталь

    private void buildPortalSteel(Tessellator t) {
        for (int side = -1; side <= 1; side += 2) {
            leg(t, side);
            horn(t, side);
            foot(t, side);
        }
        crossarm(t);
        for (int side = -1; side <= 1; side += 2) {
            guyAnchors(t, side);
        }
    }

    private void leg(Tessellator t, int side) {
        int n = 12;
        double[] ys = new double[n + 1];
        double[] cx = new double[n + 1];
        double[] hw = new double[n + 1];
        for (int i = 0; i <= n; i++) {
            ys[i] = Lep750.LEG_TOP_Y * i / n;
            cx[i] = side * Lep750.legCentreX(ys[i]);
            hw[i] = Lep750.legHalf(ys[i]);
        }
        lattice(t, ys, cx, hw, hw, 0.14D, 0.07D, 0.055D, 4);
    }

    private void horn(Tessellator t, int side) {
        double y0 = Lep750.LEG_TOP_Y;
        double y1 = Lep750.HORN_TOP_Y;
        int n = 5;
        double[] ys = new double[n];
        double[] cx = new double[n];
        double[] hw = new double[n];
        for (int i = 0; i < n; i++) {
            ys[i] = y0 + (y1 - y0) * i / (n - 1);
            cx[i] = side * Lep750.hornCentreX(ys[i]);
            hw[i] = Lep750.hornHalf(ys[i]);
        }
        lattice(t, ys, cx, hw, hw, 0.10D, 0.05D, 0.04D, 0);
        // вістря громовідводу над рогом (висота в межах 25 блоків)
        lb(t, side * Lep750.HORN_TOP_X, y1 - 0.1D, 0.0D, side * Lep750.HORN_TOP_X, y1 + 0.45D, 0.0D, 0.055D);
    }

    private void foot(Tessellator t, int side) {
        double x = side * Lep750.LEG_BASE_X;
        LepGeo.box(t, x, 0.18D, 0.0D, 1.10D, 0.18D, 1.10D);          // бетонна плита
        LepGeo.box(t, x, 0.44D, 0.0D, 0.60D, 0.09D, 0.60D);          // п'ята
        LepGeo.box(t, x, 0.68D, 0.0D, 0.30D, 0.15D, 0.30D);          // шарнір
    }

    /** Траверса: ширина 24 блоки, Warren-ферма, по центру вища (перевернута V). */
    private void crossarm(Tessellator t) {
        double y0 = Lep750.ARM_Y;
        double half = Lep750.ARM_HALF; // 12.0D
        int panels = 12;
        double[] xs = new double[panels + 1];
        double[] zh = new double[panels + 1];
        double[] yt = new double[panels + 1];
        for (int p = 0; p <= panels; p++) {
            xs[p] = -half + 2.0D * half * p / panels;
            double f = 1.0D - Math.abs(xs[p]) / half;
            zh[p] = 0.35D + 0.30D * f;
            yt[p] = y0 + 0.90D + 0.90D * f;
        }
        for (int z = -1; z <= 1; z += 2) {
            for (int p = 0; p < panels; p++) {
                lb(t, xs[p], y0, z * zh[p], xs[p + 1], y0, z * zh[p + 1], 0.11D);
                lb(t, xs[p], yt[p], z * zh[p], xs[p + 1], yt[p + 1], z * zh[p + 1], 0.09D);
                if (p < panels / 2) {
                    lb(t, xs[p], y0, z * zh[p], xs[p + 1], yt[p + 1], z * zh[p + 1], 0.06D);
                } else {
                    lb(t, xs[p], yt[p], z * zh[p], xs[p + 1], y0, z * zh[p + 1], 0.06D);
                }
            }
            for (int p = 0; p <= panels; p++) {
                lb(t, xs[p], y0, z * zh[p], xs[p], yt[p], z * zh[p], 0.07D);
            }
        }
        for (int p = 0; p <= panels; p++) {
            lb(t, xs[p], y0, -zh[p], xs[p], y0, zh[p], 0.07D);
            lb(t, xs[p], yt[p], -zh[p], xs[p], yt[p], zh[p], 0.06D);
        }
        // вушка під гірлянди
        for (double px : Lep750.PHASE_X) {
            LepGeo.box(t, px, y0 - 0.06D, 0.0D, 0.12D, 0.06D, 0.12D);
        }
    }

    /** Бетонні якорі відтяжок у землі. */
    private void guyAnchors(Tessellator t, int side) {
        for (int z = -1; z <= 1; z += 2) {
            LepGeo.box(t, side * Lep750.GUY_ANCHOR_X, 0.14D, z * Lep750.GUY_ANCHOR_Z, 0.50D, 0.14D, 0.50D);
        }
        LepGeo.box(t, side * Lep750.GUY_TIP_X, 0.14D, 0.0D, 0.50D, 0.14D, 0.50D);
    }

    // ------------------------------------------------------------ проміжна опора: гірлянди, гачки, відтяжки

    private void buildPortalAtlas(Tessellator t) {
        for (double px : Lep750.PHASE_X) {
            phaseString(t, px);
        }
        for (int side = -1; side <= 1; side += 2) {
            groundHook(t, side);
            guys(t, side);
        }
    }

    /** Гірлянда з 20 тарілок, ярмо й квадратна рамка, до кутів якої чіпляються 4 проводи. */
    private void phaseString(Tessellator t, double px) {
        double top = Lep750.STRING_TOP;
        double lastDisc = Lep750.discY(Lep750.DISCS - 1);
        double rodTop = top - 0.12D;
        double rodBottom = lastDisc - 0.20D;

        sb(t, px, Lep750.ARM_Y, 0.0D, px, top - 0.04D, 0.0D, 0.09D);
        LepGeo.boxUV(t, px, top - 0.07D, 0.0D, 0.10D, 0.05D, 0.10D, STEEL, TEX);
        LepGeo.beamUV(t, px, rodTop, 0.0D, px, Lep750.YOKE_Y, 0.0D, 0.065D, CAP, TEX);
        for (int k = 0; k < Lep750.DISCS; k++) {
            LepGeo.boxUV(t, px, Lep750.discY(k), 0.0D, 0.20D, 0.03D, 0.20D, GLASS, TEX);
        }
        LepGeo.beamUV(t, px, rodTop, 0.0D, px, rodTop - 0.14D, 0.0D, 0.13D, CAP, TEX);
        LepGeo.beamUV(t, px, rodBottom + 0.10D, 0.0D, px, rodBottom, 0.0D, 0.13D, CAP, TEX);

        // ярмо й підвіски до верхніх кутів квадрата
        double h = Lep750.BUNDLE_HALF;
        double cy = Lep750.MOUNT_Y;
        LepGeo.boxUV(t, px, Lep750.YOKE_Y, 0.0D, 0.32D, 0.04D, 0.06D, STEEL, TEX);
        for (int s = -1; s <= 1; s += 2) {
            sd(t, px + s * 0.28D, Lep750.YOKE_Y, 0.0D, px + s * h, cy + h, 0.0D, 0.035D);
        }

        // квадратна рамка, хрестовина й затискачі в кутах
        for (int k = 0; k < 4; k++) {
            int kn = (k + 1) & 3;
            double x0 = px + SIGN[k][0] * h, y0 = cy + SIGN[k][1] * h;
            double x1 = px + SIGN[kn][0] * h, y1 = cy + SIGN[kn][1] * h;
            sb(t, x0, y0, 0.0D, x1, y1, 0.0D, 0.045D);
        }
        sd(t, px - h, cy - h, 0.0D, px + h, cy + h, 0.0D, 0.025D);
        sd(t, px - h, cy + h, 0.0D, px + h, cy - h, 0.0D, 0.025D);
        for (int k = 0; k < 4; k++) {
            LepGeo.boxUV(t, px + SIGN[k][0] * h, cy + SIGN[k][1] * h, 0.0D, 0.075D, 0.075D, 0.12D, CAP, TEX);
        }
    }

    /** Гачок над рогом, на ньому ізолятор грозотроса. */
    private void groundHook(Tessellator t, int side) {
        double tipX = side * Lep750.HORN_TOP_X;
        double hookX = side * Lep750.GROUND_X;
        double gY = Lep750.GROUND_Y;
        sb(t, tipX, Lep750.HORN_TOP_Y, 0.0D, hookX, Lep750.HORN_TOP_Y, 0.0D, 0.055D);
        sb(t, hookX, Lep750.HORN_TOP_Y, 0.0D, hookX, gY + 0.16D, 0.0D, 0.05D);
        LepGeo.boxUV(t, hookX, gY + 0.13D, 0.0D, 0.08D, 0.03D, 0.08D, CAP, TEX);
        LepGeo.boxUV(t, hookX, gY + 0.07D, 0.0D, 0.17D, 0.035D, 0.17D, GLASS, TEX);
        LepGeo.boxUV(t, hookX, gY + 0.02D, 0.0D, 0.05D, 0.03D, 0.05D, CAP, TEX);
    }

    /** Відтяжки: дві по лінії та одна вбік від кінця 24-блокової траверси. */
    private void guys(Tessellator t, int side) {
        double yl = Lep750.GUY_LEG_Y;
        double lx = side * Lep750.legCentreX(yl);
        for (int z = -1; z <= 1; z += 2) {
            guy(t, lx, yl, 0.0D, side * Lep750.GUY_ANCHOR_X, 0.35D, z * Lep750.GUY_ANCHOR_Z);
        }
        guy(t, side * Lep750.ARM_HALF, Lep750.ARM_Y + 0.90D, 0.0D, side * Lep750.GUY_TIP_X, 0.35D, 0.0D);
    }

    private static void guy(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2) {
        sd(t, x1, y1, z1, x2, y2, z2, 0.055D);
        LepGeo.boxUV(t, x1, y1, z1, 0.10D, 0.10D, 0.10D, CAP, TEX);
        double f = 0.93D;
        LepGeo.boxUV(t, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, z1 + (z2 - z1) * f, 0.08D, 0.14D, 0.08D, CAP, TEX);
        LepGeo.boxUV(t, x2, y2 + 0.04D, z2, 0.12D, 0.09D, 0.12D, STEEL, TEX);
    }

    // ------------------------------------------------------------ анкерно-кутова: три вежі

    private void buildAngleSteel(Tessellator t) {
        for (int idx = -1; idx <= 1; idx++) {
            tower(t, idx * Lep750.A_TOWER_X, idx != 0);
        }
    }

    /** Одна ґратчаста вежа висотою 19 блоків. */
    private void tower(Tessellator t, double tx, boolean groundWire) {
        double[] ys = { 0.0D, 2.0D, 4.0D, 6.5D, 9.0D, 11.5D, 14.0D, 16.0D, 17.5D, Lep750.A_TOP };
        int n = ys.length;
        double[] cx = new double[n];
        double[] hw = new double[n];
        for (int i = 0; i < n; i++) {
            cx[i] = tx;
            hw[i] = Lep750.angleHalf(ys[i]);
        }
        lattice(t, ys, cx, hw, hw, 0.12D, 0.06D, 0.05D, 3);

        // посилені пояси (діафрагми)
        for (double y : new double[] { 6.5D, 11.5D }) {
            double h = Lep750.angleHalf(y) + 0.04D;
            LepGeo.box(t, tx, y, 0.0D, h, 0.05D, h);
        }

        // башмаки в основі
        double hb = Lep750.angleHalf(0.0D);
        for (int k = 0; k < 4; k++) {
            LepGeo.box(t, tx + SIGN[k][0] * hb, 0.16D, SIGN[k][1] * hb, 0.26D, 0.16D, 0.26D);
        }

        // вузол кріплення гірлянд на голівці
        LepGeo.box(t, tx, Lep750.A_MOUNT_Y, 0.0D, 0.14D, 0.10D, 0.14D);

        // громовідвід: вістря над верхівкою
        lb(t, tx, Lep750.A_TOP - 0.25D, 0.0D, tx, Lep750.A_TOP + 0.45D, 0.0D, 0.055D);
        if (groundWire) {
            LepGeo.box(t, tx, Lep750.A_GROUND_Y, 0.0D, 0.11D, 0.05D, 0.11D);
        }
    }
}

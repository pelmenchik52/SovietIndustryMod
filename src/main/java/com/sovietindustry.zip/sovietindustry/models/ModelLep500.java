package com.sovietindustry.models;

import org.lwjgl.opengl.GL11;

import com.sovietindustry.SovietIndustryMod;
import com.sovietindustry.render.LepGeo;
import com.sovietindustry.tileentities.Lep500;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.ResourceLocation;

/**
 * Проміжна Λ-подібна опора 500 кВ на відтяжках. Каркас (ноги, траверса, роги) має ті самі габарити, що й ПП750;
 * гірлянди по 18 тарілок, окрім внутрішніх відтяжок до центрального якоря є бічні відтяжки вперед і назад.
 */
@SideOnly(Side.CLIENT)
public class ModelLep500 {

    private static final ResourceLocation ATLAS =
        new ResourceLocation(SovietIndustryMod.MODID, "textures/models/lep110_single.png");
    private static final ResourceLocation LATTICE_STEEL =
        new ResourceLocation(SovietIndustryMod.MODID, "textures/models/lep_steel.png");
    private static final double TEX = 128.0D;

    private static final double[] STEEL = { 64.0D, 4.0D, 80.0D, 12.0D };
    private static final double[] STEEL_DARK = { 0.0D, 84.0D, 16.0D, 92.0D };
    private static final double[] GLASS = { 64.0D, 50.0D, 80.0D, 54.0D };
    private static final double[] CAP = { 96.0D, 48.0D, 112.0D, 56.0D };

    private static final int[][] SIGN = { { -1, -1 }, { 1, -1 }, { 1, 1 }, { -1, 1 } };

    private int listSteel = -1;
    private int listAtlas = -1;

    public void renderAll() {
        if (listSteel < 0) {
            listSteel = GLAllocation.generateDisplayLists(1);
            GL11.glNewList(listSteel, GL11.GL_COMPILE);
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            buildPortalSteel(t);
            t.draw();
            GL11.glEndList();
        }
        Minecraft.getMinecraft().renderEngine.bindTexture(LATTICE_STEEL);
        GL11.glCallList(listSteel);

        if (listAtlas < 0) {
            listAtlas = GLAllocation.generateDisplayLists(1);
            GL11.glNewList(listAtlas, GL11.GL_COMPILE);
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            buildPortalAtlas(t);
            t.draw();
            GL11.glEndList();
        }
        Minecraft.getMinecraft().renderEngine.bindTexture(ATLAS);
        GL11.glCallList(listAtlas);
    }

    // ------------------------------------------------------------ допоміжні

    private static void lb(Tessellator t, double[] a, double[] b, double th) {
        LepGeo.beam(t, a[0], a[1], a[2], b[0], b[1], b[2], th);
    }

    private static void lb(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beam(t, x1, y1, z1, x2, y2, z2, th);
    }

    private static void sb(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beamUV(t, x1, y1, z1, x2, y2, z2, th, STEEL, TEX);
    }

    private static void sd(Tessellator t, double x1, double y1, double z1, double x2, double y2, double z2, double th) {
        LepGeo.beamUV(t, x1, y1, z1, x2, y2, z2, th, STEEL_DARK, TEX);
    }

    private static void lattice(Tessellator t, double[] ys, double[] cx, double[] hw, double[] hd,
                                double legT, double barT, double diagT, int crossEvery) {
        int n = ys.length;
        double[][][] c = new double[n][4][];
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 4; k++) {
                c[i][k] = new double[] { cx[i] + SIGN[k][0] * hw[i], ys[i], SIGN[k][1] * hd[i] };
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int k = 0; k < 4; k++) {
                lb(t, c[i][k], c[i + 1][k], legT);
            }
        }
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 4; k++) {
                lb(t, c[i][k], c[i][(k + 1) & 3], barT);
            }
            if (crossEvery > 0 && i > 0 && i < n - 1 && i % crossEvery == 0) {
                lb(t, c[i][0], c[i][2], diagT);
                lb(t, c[i][1], c[i][3], diagT);
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int k = 0; k < 4; k++) {
                int k1 = (k + 1) & 3;
                lb(t, c[i][k], c[i + 1][k1], diagT);
                lb(t, c[i][k1], c[i + 1][k], diagT);
            }
        }
    }

    // ------------------------------------------------------------ каркас опори ПП500

    private void buildPortalSteel(Tessellator t) {
        for (int side = -1; side <= 1; side += 2) {
            leg(t, side);
            horns(t, side);
            foot(t, side);
        }
        crossarm(t);
    }

    /** Λ-подібна нога однакової ширини по всій довжині з гострим трикутним звуженням біля фундаменту. */
    private void leg(Tessellator t, int side) {
        int n = 15;
        double[] ys = new double[n + 1];
        double[] cx = new double[n + 1];
        double[] hw = new double[n + 1];
        for (int i = 0; i <= n; i++) {
            ys[i] = Lep500.LEG_TOP_Y * i / n;
            cx[i] = side * Lep500.legCentreX(ys[i]);
            hw[i] = Lep500.legHalf(ys[i]);
        }
        lattice(t, ys, cx, hw, hw, 0.15D, 0.07D, 0.055D, 2);
        // вузол-«п'ята» у вершині ноги, куди сходяться пояси траверси
        LepGeo.box(t, side * Lep500.LEG_TOP_X, Lep500.LEG_TOP_Y, 0.0D, 0.55D, 0.10D, 0.55D);
    }

    private void foot(Tessellator t, int side) {
        double x = side * Lep500.LEG_BASE_X;
        // Опорний шарнірний башмак під трикутним вістрям ноги
        LepGeo.box(t, x, 0.15D, 0.0D, 0.65D, 0.15D, 0.65D);
    }

    /** Похилий ріг тросостійки з горизонтальним козирком назовні (як на кресленні ПП500). */
    private void horns(Tessellator t, int side) {
        double y0 = Lep500.ARM_TOP_LEG_Y - 0.15D;
        double y1 = Lep500.HORN_TOP_Y;
        int n = 6;
        double[] ys = new double[n];
        double[] cx = new double[n];
        double[] hw = new double[n];
        for (int i = 0; i < n; i++) {
            double f = (double) i / (n - 1);
            ys[i] = y0 + (y1 - y0) * f;
            cx[i] = side * (Lep500.LEG_TOP_X + Lep500.HORN_SPREAD * f);
            hw[i] = 0.42D + (0.20D - 0.42D) * f;
        }
        lattice(t, ys, cx, hw, hw, 0.13D, 0.065D, 0.05D, 2);

        // Горизонтальний козирок на вершині рога, винесений назовні (як на кресленні ПП500)
        double topX = cx[n - 1];
        double tipX = side * Lep500.GROUND_X;
        double botY = y1 - 0.45D;
        for (int z = -1; z <= 1; z += 2) {
            double zw = 0.18D;
            lb(t, topX - side * 0.2D, y1, z * zw, tipX, y1, z * 0.06D, 0.11D);
            lb(t, topX + side * 0.15D, botY, z * zw, tipX, y1, z * 0.06D, 0.09D);
            lb(t, topX, y1, z * zw, topX + side * 0.15D, botY, z * zw, 0.07D);
        }
        lb(t, tipX, y1, -0.25D, tipX, y1, 0.25D, 0.09D);
    }

    /**
     * Траверса ПП500: двоскатний верхній пояс (підйом до центру) та V-подібний нижній пояс,
     * що спирається на вершини обох ніг і сходиться в центрі та на гострих консолях.
     */
    private void crossarm(Tessellator t) {
        double half = Lep500.ARM_HALF;
        int panels = 20;
        double[] xs = new double[panels + 1];
        double[] yt = new double[panels + 1];
        double[] yb = new double[panels + 1];
        double[] zh = new double[panels + 1];
        for (int p = 0; p <= panels; p++) {
            xs[p] = -half + 2.0D * half * p / panels;
            yt[p] = Lep500.armTopY(xs[p]);
            yb[p] = Lep500.armBottomY(xs[p]);
            zh[p] = 0.22D + 0.48D * Lep500.armTri(xs[p]);
        }

        for (int z = -1; z <= 1; z += 2) {
            for (int p = 0; p < panels; p++) {
                lb(t, xs[p], yt[p], z * zh[p], xs[p + 1], yt[p + 1], z * zh[p + 1], 0.13D);
                lb(t, xs[p], yb[p], z * zh[p], xs[p + 1], yb[p + 1], z * zh[p + 1], 0.13D);
                if (p % 2 == 0) {
                    lb(t, xs[p], yt[p], z * zh[p], xs[p + 1], yb[p + 1], z * zh[p + 1], 0.06D);
                } else {
                    lb(t, xs[p], yb[p], z * zh[p], xs[p + 1], yt[p + 1], z * zh[p + 1], 0.06D);
                }
            }
            for (int p = 1; p < panels; p++) {
                lb(t, xs[p], yb[p], z * zh[p], xs[p], yt[p], z * zh[p], 0.07D);
            }
        }
        // Центральна вертикальна стійка симетрії траверси
        lb(t, 0.0D, Lep500.ARM_Y, -0.25D, 0.0D, Lep500.ARM_TOP_MID_Y, 0.25D, 0.11D);

        for (int p = 1; p < panels; p++) {
            lb(t, xs[p], yb[p], -zh[p], xs[p], yb[p], zh[p], 0.07D);
            lb(t, xs[p], yt[p], -zh[p], xs[p], yt[p], zh[p], 0.065D);
            if (p % 2 == 0 && p < panels - 1) {
                lb(t, xs[p], yt[p], -zh[p], xs[p + 1], yt[p + 1], zh[p + 1], 0.045D);
                lb(t, xs[p], yt[p], zh[p], xs[p + 1], yt[p + 1], -zh[p + 1], 0.045D);
            }
        }

        // Поздовжні кронштейни під подвійні гірлянди на кожній фазі
        double halfZ = Lep500.STRING_SPACING * 0.5D;
        for (double px : Lep500.PHASE_X) {
            double by = Lep500.armBottomY(px);
            lb(t, px, by - 0.04D, -halfZ, px, by - 0.04D, halfZ, 0.10D);
            for (int sz = -1; sz <= 1; sz += 2) {
                LepGeo.box(t, px, by - 0.08D, sz * halfZ, 0.10D, 0.07D, 0.10D);
            }
        }
    }

    // ------------------------------------------------------------ гірлянди (18 тарілок), відтяжки

    private void buildPortalAtlas(Tessellator t) {
        for (double px : Lep500.PHASE_X) {
            phaseString(t, px);
        }
        for (int side = -1; side <= 1; side += 2) {
            groundHook(t, side);
            double topX = side * Lep500.LEG_TOP_X;
            double topY = Lep500.LEG_TOP_Y - 0.15D;
            // Внутрішня відтяжка до центрального фундаментного якоря (вигляд спереду: V)
            sd(t, topX, topY, 0.0D, 0.0D, 0.35D, 0.0D, 0.055D);
            LepGeo.boxUV(t, topX, topY, 0.0D, 0.10D, 0.10D, 0.10D, CAP, TEX);
            // Бічні відтяжки вперед і назад (вигляд збоку: трикутник із вершиною на верху ноги)
            for (int fz = -1; fz <= 1; fz += 2) {
                double ax = side * Lep500.GUY_ANCHOR_X;
                double az = fz * Lep500.GUY_Z;
                sd(t, topX, topY, 0.0D, ax, 0.30D, az, 0.055D);
                LepGeo.boxUV(t, ax, 0.14D, az, 0.26D, 0.14D, 0.26D, STEEL, TEX);
            }
        }
        LepGeo.boxUV(t, 0.0D, 0.22D, 0.0D, 0.32D, 0.22D, 0.32D, STEEL, TEX);
    }

    private void phaseString(Tessellator t, double px) {
        double top = Lep500.STRING_TOP;
        double lastDisc = Lep500.discY(Lep500.DISCS - 1);
        double rodTop = top - 0.12D;
        double rodBottom = lastDisc - 0.16D;
        double halfZ = Lep500.STRING_SPACING * 0.5D;
        double by = Lep500.armBottomY(px);

        for (int sz = -1; sz <= 1; sz += 2) {
            double zPos = sz * halfZ;
            sb(t, px, by - 0.04D, zPos, px, top - 0.04D, zPos, 0.08D);
            LepGeo.boxUV(t, px, top - 0.07D, zPos, 0.09D, 0.06D, 0.09D, STEEL, TEX);
            LepGeo.beamUV(t, px, rodTop, zPos, px, Lep500.YOKE_Y, zPos, 0.055D, CAP, TEX);
            for (int k = 0; k < Lep500.DISCS; k++) {
                LepGeo.boxUV(t, px, Lep500.discY(k), zPos, 0.19D, 0.03D, 0.19D, GLASS, TEX);
            }
            LepGeo.beamUV(t, px, rodTop, zPos, px, rodTop - 0.12D, zPos, 0.11D, CAP, TEX);
            LepGeo.beamUV(t, px, rodBottom + 0.12D, zPos, px, rodBottom, zPos, 0.11D, CAP, TEX);
        }

        double cy = Lep500.MOUNT_Y;
        double h = Lep500.BUNDLE_HALF;
        LepGeo.boxUV(t, px, Lep500.YOKE_Y, 0.0D, 0.09D, 0.065D, halfZ + 0.16D, STEEL, TEX);
        sd(t, px, Lep500.YOKE_Y - 0.08D, -halfZ, px, Lep500.YOKE_Y - 0.08D, halfZ, 0.045D);
        sb(t, px, Lep500.YOKE_Y, 0.0D, px, cy + h, 0.0D, 0.06D);

        for (int k = 0; k < 4; k++) {
            int kn = (k + 1) & 3;
            double x0 = px + SIGN[k][0] * h, y0 = cy + SIGN[k][1] * h;
            double x1 = px + SIGN[kn][0] * h, y1 = cy + SIGN[kn][1] * h;
            sb(t, x0, y0, 0.0D, x1, y1, 0.0D, 0.04D);
        }
        sd(t, px - h, cy - h, 0.0D, px + h, cy + h, 0.0D, 0.025D);
        sd(t, px - h, cy + h, 0.0D, px + h, cy - h, 0.0D, 0.025D);
        for (int k = 0; k < 4; k++) {
            LepGeo.boxUV(t, px + SIGN[k][0] * h, cy + SIGN[k][1] * h, 0.0D, 0.075D, 0.075D, 0.11D, CAP, TEX);
        }
    }

    /** Затискач грозотроса на кінці козирка рога. */
    private void groundHook(Tessellator t, int side) {
        double hookX = side * Lep500.GROUND_X;
        double gY = Lep500.GROUND_Y;
        sb(t, hookX, Lep500.HORN_TOP_Y, 0.0D, hookX, gY + 0.10D, 0.0D, 0.065D);
        LepGeo.boxUV(t, hookX, gY + 0.10D, 0.0D, 0.10D, 0.04D, 0.10D, CAP, TEX);
        LepGeo.boxUV(t, hookX, gY + 0.03D, 0.0D, 0.18D, 0.035D, 0.18D, GLASS, TEX);
        LepGeo.boxUV(t, hookX, gY - 0.03D, 0.0D, 0.065D, 0.035D, 0.065D, CAP, TEX);
    }
}

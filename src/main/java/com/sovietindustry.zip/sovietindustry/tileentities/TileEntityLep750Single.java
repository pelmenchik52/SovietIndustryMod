package com.sovietindustry.tileentities;

import com.sovietindustry.api.IStandoffPylon;

import net.minecraft.util.Vec3;

/**
 * Окрема анкерно-кутова щогла 750 кВ на ОДНУ фазу (розщеплена фаза 2x4 дроти).
 * Три такі щогли замінюють одну анкерно-кутову опору, коли її не можна поставити на рівний майданчик (гори):
 * кожна стоїть на своїй висоті, а до проміжної опори тягнеться свій дріт. Для NTM це звичайний вузол TRIPLE
 * (щоб котушка з'єднувала з опорами того ж типу), але візуально використовується лише одна точка кріплення.
 * Грозозахисного троса щогла не має.
 */
public class TileEntityLep750Single extends TileEntityLep750Base implements IStandoffPylon {
    private static final double[][] NO_GROUND = new double[0][];

    public TileEntityLep750Single() {
    }

    @Override
    protected double[][] getLocalMounts() {
        return Lep750.sMounts();
    }

    @Override
    protected double[][] getLocalGround() {
        return NO_GROUND;
    }

    @Override
    public Vec3[] getGroundMounts() {
        return new Vec3[0];
    }

    @Override
    public Vec3 getGroundMount() {
        return null;
    }

    @Override
    public boolean hasAnchorStrings() {
        return true;
    }

    @Override
    public double getStringLength() {
        return Lep750.A_STRING_LEN;
    }

    @Override
    public double getStringStandoff(int mount, double dirX, double dirZ) {
        return Lep750.A_STANDOFF;
    }

    /** Одна точка кріплення: усі дроти (вхід і вихід) чіпляються до неї. */
    @Override
    public int[] getLinkMounts(int x, int y, int z) {
        return null;
    }
}

package com.sovietindustry.tileentities;

/**
 * Проміжна портальна опора 500 кВ на відтяжках. Габарити (висота, ноги, траверса, роги, відстань між фазами)
 * ті самі, що в проміжної опори 750 кВ, тому геометрія делегується {@link Lep750}: мультиблок, колізія й
 * розміщення (LepMultiblock.*P750*) працюють для обох опор однаково. Відмінності від 750 кВ:
 *  - гірлянда має на 2 тарілки менше (18 замість 20), тож точка кріплення фази на 0.35 блока вище;
 *  - окрім внутрішніх відтяжок до центрального якоря, є ще бічні відтяжки вперед і назад (вигляд збоку трикутником).
 */
public final class Lep500 {
    private Lep500() {
    }

    /** Максимальна довжина прольоту між опорами 500 кВ у блоках. */
    public static final double MAX_SPAN_500 = 225.0D;

    // ---------------------------------------------------------------- пучок (як на 750 кВ)
    public static final int STRINGS = Lep750.STRINGS;
    public static final double STRING_SPACING = Lep750.STRING_SPACING;
    public static final int WIRES_PER_STRING = Lep750.WIRES_PER_STRING;
    public static final double BUNDLE_HALF = Lep750.BUNDLE_HALF;
    public static final double WIRE_SPACING = Lep750.WIRE_SPACING;

    // ---------------------------------------------------------------- габарити (ті самі, що в ПП750)
    public static final int HEIGHT = Lep750.HEIGHT;
    public static final double LEG_BASE_X = Lep750.LEG_BASE_X;
    public static final double LEG_TOP_X = Lep750.LEG_TOP_X;
    public static final double LEG_TOP_Y = Lep750.LEG_TOP_Y;
    public static final double ARM_HALF = Lep750.ARM_HALF;
    public static final double ARM_Y = Lep750.ARM_Y;
    public static final double ARM_TOP_LEG_Y = Lep750.ARM_TOP_LEG_Y;
    public static final double ARM_TOP_MID_Y = Lep750.ARM_TOP_MID_Y;
    public static final double HORN_TOP_Y = Lep750.HORN_TOP_Y;
    public static final double HORN_SPREAD = Lep750.HORN_SPREAD;
    public static final double HORN_TIP_OUT = Lep750.HORN_TIP_OUT;
    public static final double GROUND_X = Lep750.GROUND_X;
    public static final double GROUND_Y = Lep750.GROUND_Y;
    public static final double[] PHASE_X = Lep750.PHASE_X;

    // ---------------------------------------------------------------- гірлянда: 18 тарілок
    /** Скільки тарілок у гірлянді (на 750 кВ їх 20). */
    public static final int DISCS = Lep750.DISCS - 2;
    /** Крок тарілок уздовж гірлянди (як у {@link Lep750#discY(int)}). */
    public static final double DISC_STEP = 0.175D;
    /** Верх гірлянди під нижнім поясом траверси. */
    public static final double STRING_TOP = Lep750.STRING_TOP;
    /** Коромисло (ярмо) під гірляндою: вище, ніж у 750 кВ, на різницю тарілок. */
    public static final double YOKE_Y = Lep750.YOKE_Y + (Lep750.DISCS - DISCS) * DISC_STEP;
    /** Центр пучка проводів: на 0.40 нижче коромисла, як і в 750 кВ. */
    public static final double MOUNT_Y = YOKE_Y - 0.40D;

    public static double discY(int k) {
        return STRING_TOP - 0.28D - k * DISC_STEP;
    }

    // ---------------------------------------------------------------- бічні відтяжки (вигляд збоку трикутником)
    /** Бічні відтяжки вперед і назад: якорі на цій відстані по Z від осі опори. */
    public static final double GUY_Z = 8.0D;
    /** Якір бічної відтяжки по X: під п'ятою своєї ноги, тому в профіль відтяжка лягає вздовж ноги. */
    public static final double GUY_ANCHOR_X = LEG_BASE_X;

    // ---------------------------------------------------------------- форма (делегується до ПП750)
    public static double legCentreX(double y) {
        return Lep750.legCentreX(y);
    }

    public static double legHalf(double y) {
        return Lep750.legHalf(y);
    }

    public static double armTri(double ax) {
        return Lep750.armTri(ax);
    }

    public static double armBottomY(double x) {
        return Lep750.armBottomY(x);
    }

    public static double armTopY(double x) {
        return Lep750.armTopY(x);
    }

    public static double[][] pMounts() {
        return new double[][] {
            { PHASE_X[0], MOUNT_Y, 0.0D },
            { PHASE_X[1], MOUNT_Y, 0.0D },
            { PHASE_X[2], MOUNT_Y, 0.0D }
        };
    }
}
